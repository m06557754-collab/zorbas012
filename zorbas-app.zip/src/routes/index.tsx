import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Zorbas iOS Build Kit" },
      {
        name: "description",
        content:
          "Build an unsigned Zorbas .ipa for iPhone from any PC using Capacitor and GitHub Actions.",
      },
      { property: "og:title", content: "Zorbas iOS Build Kit" },
      {
        property: "og:description",
        content: "Capacitor wrapper + GitHub Actions workflow that produces a Zorbas .ipa.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const steps = [
  "Push this project to your GitHub repo.",
  "Open the Actions tab, pick “Build iOS app (Capacitor)”, click Run workflow.",
  "Wait ~10 minutes, then download the ios-build artifact.",
  "On Windows, install Zorbas-unsigned.ipa with Sideloadly using your free Apple ID.",
];

function Index() {
  return (
    <main className="mx-auto flex min-h-screen max-w-2xl flex-col justify-center gap-8 px-6 py-16">
      <header className="space-y-2">
        <p className="text-sm uppercase tracking-widest text-muted-foreground">iOS build kit</p>
        <h1 className="text-4xl font-bold tracking-tight text-foreground">Zorbas</h1>
        <p className="text-muted-foreground">
          Bundle ID <code className="rounded bg-muted px-1.5 py-0.5">com.zorbas.app</code> · wraps{" "}
          <span className="text-foreground">zorbas12-github-io.vercel.app</span>
        </p>
      </header>

      <ol className="space-y-3">
        {steps.map((step, i) => (
          <li key={step} className="flex gap-3 rounded-lg border border-border bg-card p-4">
            <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary text-xs font-semibold text-primary-foreground">
              {i + 1}
            </span>
            <span className="text-sm text-card-foreground">{step}</span>
          </li>
        ))}
      </ol>

      <p className="text-xs text-muted-foreground">
        The .ipa is unsigned, so it expires after 7 days on a free Apple ID and must be reinstalled.
      </p>
    </main>
  );
}
